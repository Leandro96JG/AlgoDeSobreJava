package com.errors.springboot.springboot_error;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootErrorApplicationTests {

	@Test
	void contextLoads() {
	}

}
